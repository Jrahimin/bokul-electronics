@extends('layouts.app2')

@section('header')

@endsection

@section('content')

    {!! Form::open(['method'=>'POST','action'=>'ItemsController@sellStore','class'=>'form-horizontal']) !!}
    {{csrf_field()}}
    <fieldset>
        <legend class="heading">Sell Item</legend>
        <div class="form-group">
            <label class="control-label col-sm-2" for="item_id">Product Id</label>
            <div class="col-sm-4">
                <select class="form-control" id="item_id" name="item_id"  required="required">
                    <option value="">--Select an item--</option>
                    @foreach($items as $item)
                        {
                            <option value="{{$item->id}}">id: {{$item->id}} &nbsp; {{$item->title}}; &nbsp; {{$item->description}}</option>
                        }
                    @endforeach
                </select>
            </div>
        </div>

        <div class="form-group">
            <label class="control-label col-sm-2" for="no_item">Number of Item</label>
            <div class="col-sm-4">
                <input type="text" class="form-control" id="no_item" name="no_item"  required="required">
            </div>
        </div>

        <div class="form-group">
            <label class="control-label col-sm-2" for="sell_price">Price</label>
            <div class="col-sm-4">
                <input type="text" class="form-control" id="sell_price" name="sell_price"  required="required">
            </div>
        </div>

        <div class="form-group">
            <label class="control-label col-sm-2" for="sell_type">Sale Type</label>
            <div class="col-sm-4">
                <select class="form-control" id="sell_type" name="sell_type" required="required" onchange="showInstall(this.value);">
                    <option value="">--Select sale type--</option>
                    <option value="Instant">Instant payment</option>
                    <option value="Installment">Pay in Installments</option>
                </select>
            </div>
        </div>

        <div class="form-group" style="display: none" id="no_of_inst_div">
            <label class="control-label col-sm-2" for="no_of_inst">Number of Installment</label>
            <div class="col-sm-4">
                <input type="text" class="form-control" id="no_of_inst" name="no_of_inst">
            </div>
        </div>

        <div class="form-group">
            <label class="control-label col-sm-2" for="cust_id">Customer Id</label>
            <div class="col-sm-4">
                <select class="form-control" id="cust_id" name="cust_id"  required="required">
                    <option value="">--Select a Customer--</option>
                    @foreach($customers as $customer)
                        {
                        <option value="{{$customer->id}}">id: {{$customer->id}} &nbsp; {{$customer->name}}</option>
                        }
                    @endforeach
                </select>
            </div>
        </div>

        <input type="hidden" name="user_id" id="user_id" value="{{$userId}}">

        <input type="hidden" id="date" name="date" value="{{\Carbon\Carbon::today()->setTimezone('Asia/Dacca')->toDateString()}}">

        <div class="form-group">
            <div class="col-sm-offset-2 col-sm-12">
                <button type="submit" id="submit" name="submit" class="btn btn-lg btn-primary" style="margin-left: 25.5%;font-weight:bold;">Add</button>
            </div>
        </div>

        @if($success==2)
            <br>
            <label id="successLabel" style="margin-left: 24%">{{$msg}}</label>
        @endif
        @if($success==1)
            <label id="failedLabel" style="margin-left: 24%">{{$msg}}</label>
        @endif

    </fieldset>
    </form>

@endsection

@section('footer')

@endsection


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<script type="text/javascript">
        function showInstall(payType)
        {
            if(payType=="Installment")
            {
                document.getElementById("no_of_inst_div").style.display="block";
                document.getElementById("no_of_inst").setAttribute("required", "required");
            }
            else
            {
                document.getElementById("no_of_inst_div").style.display="none";
                document.getElementById("no_of_inst").removeAttribute("required");
            }
        }
</script>