<!DOCTYPE html>
<html>
<head>

    <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <style>
        html, body{
            margin: 0;
            padding: 0;
            height: 100%;
            background-color: #ebfad1;
        }
        .image, .footer-image{
            position: relative;
        }
        img{
            display: block;
        }
        .image h4{
            position: absolute;
            top: 7%;
            left: 8%;
            width: 100%;
            color: #411c0e;
            font: bold 16px/30px Helvetica, Sans-Serif;
            letter-spacing: -1px;
        }
        .footer-image h4{
            position: absolute;
            top: 7%;
            text-align: center;
            width: 100%;
            color: black;
            font: bold 16px/30px Helvetica, Sans-Serif;
        }
        .container{
            min-height: 100%;
            height: auto;
            margin-left: 10%;
            margin-top: 5%;
            margin-bottom: -60px;
            display: block;
        }
       .nav ul{
            list-style-type: none;
            margin: 0;
            padding: 0;
        }
        .nav li{
            float: left;
            border-right: solid black 1px;
            width: 20%;
            border-bottom: solid black 1px;
        }
        .nav a:link, a:visited{
            display: block;
            background-color: yellowgreen;

            color: floralwhite;
            text-decoration: none;
            text-align: center;
            font-weight: bold;
            padding: 8px;
        }
        .nav a:hover, a:active{
            background-color: darkgreen;
        }
        .footer{
            height: 60px;
        }
        #successLabel{
            color: darkgreen;
            font-weight: bold;
            font-size: 16px;
        }
        #failedLabel{
            color: darkred;
            font-weight: bold;
            font-size: 16px;
        }
    </style>
</head>
<body>

<div class="header">
    <div class="image">
        <img src="{{asset('bokul header.jpg')}}" style="width: 100%; height: 100px;"/>
        <h4>Bokul Electronics<br>College Market, Ranisonkail, Thakurgaon.</h4>
        </div>
        @yield('header')

    <div class="nav">
        <ul>
            <li><a href="{{url('register')}}">User</a></li>
            <li><a href="{{url('customer/create')}}">Cutomer</a></li>
            <li><a href="{{url('item/create')}}">Item</a></li>
            <li><a href="{{url('stock/create')}}">Stock</a></li>
            <li><a href="{{url('item/item_sell')}}">Sell Item</a></li>
        </ul>
    </div>
</div>

<div class="container">
    <div class="content">
    @yield('content')

    </div>
</div>

<div class="footer">
    <div class="footer-image">
    <img src="{{asset('bokul footer.jpg')}}" style="width: 100%; height: 60px;"/>
    <h4>&copy; Developed by skyhigh.com</h4>
    </div>
@yield('footer')
</div>

</body>
</html>
