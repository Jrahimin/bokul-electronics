<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <style>
        html, body{
            height: 100%;
            background-color: #ebfad1;
            margin: 0;
            padding: 0;
        }
        #app{
            min-height: 100%;
            margin-bottom: -60px;
        }
        .image, .footer-image{
            position: relative;
        }
        .image h4{
            position: absolute;
            top: 7%;
            left: 8%;
            width: 100%;
            color: #411c0e;
            font: bold 16px/30px Helvetica, Sans-Serif;
            letter-spacing: -1px;
        }
        .footer-image h4{
            position: absolute;
            top: 7%;
            text-align: center;
            width: 100%;
            color: black;
            font: bold 16px/30px Helvetica, Sans-Serif;
        }
        .nave ul{
            list-style-type: none;
            margin: 0;
            padding: 0;
        }
        .nave li{
            float: left;
            border-right: solid black 1px;
            width: 20%;
        }
        .nave a:link, a:visited{
            display: block;
            background-color: yellowgreen;

            color: floralwhite;
            text-decoration: none;
            text-align: center;
            font-weight: bold;
            padding: 8px;
        }
        .nave a:hover, a:active{
            background-color: darkgreen;
        }
        .footer{
            height: 50px;
        }
    </style>

</head>
<body>

<div class="header">
    <div class="image">
        <img src="{{asset('bokul header.jpg')}}" style="width: 100%; height: 100px;"/>
        <h4>Bokul Electronics<br>College Market, Ranisonkail, Thakurgaon.</h4>
    </div>
    @yield('header')

    <div class="nave">
        <ul>
            <li><a href="{{url('register')}}">User</a></li>
            <li><a href="{{url('customer/create')}}">Cutomer</a></li>
            <li><a href="{{url('item/create')}}">Item</a></li>
            <li><a href="{{url('stock/create')}}">Stock</a></li>
            <li><a href="{{url('item/item_sell')}}">Sell Item</a></li>
        </ul>
    </div>
</div>
<br><br>
    <div id="app">
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        &nbsp;
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        @if (Auth::guest())
                            <li><a href="{{ route('login') }}">Login</a></li>
                            <li><a href="{{ route('register') }}">Add User</a></li>
                        @else
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    {{ Auth::user()->name }} <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="{{ route('logout') }}"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                            {{ csrf_field() }}
                                        </form>
                                    </li>
                                </ul>
                            </li>
                        @endif
                    </ul>
                </div>
            </div>
        </nav>

        @yield('content')
    </div>

<div class="footer">
    <div class="footer-image">
        <img src="{{asset('bokul footer.jpg')}}" style="width: 100%; height: 60px;"/>
        <h4>&copy; Developed by skyhigh.com</h4>
    </div>
    @yield('footer')
</div>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}"></script>
</body>
</html>
